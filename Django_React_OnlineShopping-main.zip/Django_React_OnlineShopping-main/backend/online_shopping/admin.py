from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from django.contrib.auth.forms import UserCreationForm, UserChangeForm
from .models import User, BillingAddress, ShippingAddress, Category, SubCategory, Product, ProductReview, Order, \
    OrderDetails, Cart, CartItem, ContactUs


# Register your models here.
@admin.register(User)
class UserAdmin(BaseUserAdmin):
    form = UserChangeForm
    fieldsets = (
        (None, {'fields': ('email', 'password')}),
        ('Personal info', {'fields': ('first_name', 'last_name')}),
        ('Permissions', {'fields': ('is_active', 'is_staff', 'is_superuser', 'groups', 'user_permissions')}),
        ('Important dates', {'fields': ('last_login', 'date_joined')}),
        ('User Info', {'fields': ('gender', 'contact_number', 'image')}),
    )
    add_fieldsets = (
        (None, {
            'classes': ('wide', 'extrapretty'),
            'fields': ('email', 'password1', 'password2')
        }),
        ('Personal info', {
            'classes': ('wide', 'extrapretty'),
            'fields': ('first_name', 'last_name')
        }),
        ('Permissions', {
            'classes': ('wide', 'extrapretty'),
            'fields': ('is_active', 'is_staff', 'is_superuser', 'groups', 'user_permissions')
        }),
        ('Important dates', {
            'classes': ('wide', 'extrapretty'),
            'fields': ('last_login', 'date_joined')
        }),
        ('User Info', {
            'classes': ('wide', 'extrapretty'),
            'fields': ('gender', 'contact_number', 'image')
        }),
    )
    add_form = UserCreationForm
    search_fields = ['email', 'first_name', 'last_name']
    list_display = ['id', 'email', 'first_name', 'last_name', 'is_staff', 'is_superuser', 'date_joined']
    list_filter = ['date_joined', 'is_superuser', 'is_staff', 'last_login', 'date_joined']
    ordering = None


@admin.register(BillingAddress)
class BillingAddressAdmin(admin.ModelAdmin):
    list_display = ['id', 'user', 'created_at']
    list_filter = ['country', 'state', 'city']


@admin.register(ShippingAddress)
class ShippingAddressAdmin(admin.ModelAdmin):
    list_display = ['id', 'user', 'created_at']
    list_filter = ['country', 'state', 'city']


@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ['id', 'category_name', 'created_at']


@admin.register(SubCategory)
class SubCategoryAdmin(admin.ModelAdmin):
    list_display = ['id', 'sub_category_name', 'category', 'created_at']


@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ['id', 'product_name', 'product_quantity', 'product_price', 'created_at']


@admin.register(ProductReview)
class ProductReviewAdmin(admin.ModelAdmin):
    list_display = ['id', 'product_rating', 'product', 'user', 'created_at']
    list_filter = ['product_rating', 'created_at']


@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    list_display = ['id', 'is_delivered', 'user', 'created_at']
    list_filter = ['is_delivered', 'created_at']


@admin.register(OrderDetails)
class OrderDetailsAdmin(admin.ModelAdmin):
    list_display = ['id', 'order', 'product', 'order_quantity', 'created_at']
    list_filter = ['created_at']


@admin.register(Cart)
class CartAdmin(admin.ModelAdmin):
    list_display = ['id', 'user', 'created_at']
    list_filter = ['created_at']


@admin.register(CartItem)
class CartItemAdmin(admin.ModelAdmin):
    list_display = ['id', 'cart', 'product', 'created_at']


@admin.register(ContactUs)
class ContactUsAdmin(admin.ModelAdmin):
    list_display = ['id', 'first_name', 'last_name', 'email', 'created_at']
    list_filter = ['email', 'created_at']
