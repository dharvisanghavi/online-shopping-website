from django.urls import path, include
from . import views
from rest_framework.routers import DefaultRouter
from django.conf import settings
from rest_framework_simplejwt.views import TokenRefreshView

# creating router object
router = DefaultRouter()

# Register View sets with Router
router.register('users', views.UserViewSet, basename="users")
router.register('billing-addresses', views.BillingAddressViewSet, basename="billing-addresses")
router.register('shipping-addresses', views.ShippingAddressViewSet, basename="shipping-addresses")
router.register('categories', views.CategoryViewSet, basename="categories")
router.register('subcategories', views.SubCategoryViewSet, basename="subcategories")
router.register('products', views.ProductViewSet, basename="products")
router.register('product-reviews', views.ProductReviewViewSet, basename="product-reviews")
router.register('orders', views.OrderViewSet, basename="orders")
router.register('order-details', views.OrderDetailsViewSet, basename="order-details")
router.register('cart', views.CartViewSet, basename="cart")
router.register('cart-items', views.CartViewSet, basename="cart-items")
router.register('contactus', views.ContactUsViewSet, basename="contactus")

urlpatterns = [
    path('', include(router.urls)),
    path('login/', views.MyObtainTokenPairView.as_view(), name='token_obtain_pair'),
    path('login/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
]
