import os
from django.utils import timezone
from django.contrib.auth.base_user import BaseUserManager
from django.contrib.auth.models import AbstractUser
from django.db import models
from django_countries.fields import CountryField

from django.utils.translation import ugettext_lazy as _
from django.utils.deconstruct import deconstructible


# Create your models here.


@deconstructible
class UploadToPathAndRename(object):

    def __init__(self, path):
        self.sub_path = path

    def __call__(self, instance, filename):
        ext = filename.split('.')[-1]
        # get filename
        if instance.pk:
            filename = '{}.{}'.format(instance.pk, ext)
        else:
            # set filename as random string
            filename = '{}.{}'.format(timezone.now(), ext)
        # return the whole path to the file
        return os.path.join(self.sub_path, filename)


class UserManager(BaseUserManager):
    """
    Custom user model manager where email is the unique identifiers
    for authentication instead of usernames.
    """

    def create_user(self, email, password, **extra_fields):
        """
        Create and save a User with the given email and password.
        """
        if not email:
            raise ValueError(_('The Email must be set'))
        email = self.normalize_email(email)
        user = self.model(email=email, **extra_fields)
        user.set_password(password)
        user.save()
        return user

    def create_superuser(self, email, password, **extra_fields):
        """
        Create and save a SuperUser with the given email and password.
        """
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)
        extra_fields.setdefault('is_active', True)

        if extra_fields.get('is_staff') is not True:
            raise ValueError(_('Superuser must have is_staff=True.'))
        if extra_fields.get('is_superuser') is not True:
            raise ValueError(_('Superuser must have is_superuser=True.'))
        return self.create_user(email, password, **extra_fields)


class User(AbstractUser):
    username = None
    first_name = models.CharField(_('first name'), max_length=150, blank=False)
    last_name = models.CharField(_('last name'), max_length=150, blank=False)
    email = models.EmailField(_('email address'), unique=True, error_messages={
        'unique': _("A user with that email already exists."),
    })
    contact_number = models.CharField(_("contact number"), max_length=12, blank=True)
    gender = models.CharField(_("gender"), max_length=10, choices=(("Male", "male"), ("Female", "female")), null=True, blank=True)
    image = models.ImageField(_("image"), upload_to=UploadToPathAndRename("User/images"), default="",
                              blank=True)

    EMAIL_FIELD = 'email'
    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['first_name', 'last_name']

    objects = UserManager()

    def __str__(self):
        return self.get_username()


class BillingAddress(models.Model):
    id = models.BigAutoField(_("id"), primary_key=True, auto_created=True)
    billing_address = models.TextField(_("billing address"))
    city = models.CharField(_("city"), max_length=50)
    state = models.CharField(_("state"), max_length=50)
    country = CountryField(_("country"),max_length=50)
    zip_code = models.IntegerField(_("zip code"))
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    created_at = models.DateTimeField(_("created at"), auto_now_add=True)

    def __str__(self):
        return str(self.id)

    class Meta:
        verbose_name = "Billing Address"
        verbose_name_plural = "Billing Addresses"


class ShippingAddress(models.Model):
    id = models.BigAutoField(_("id"), primary_key=True, auto_created=True)
    shipping_address = models.TextField(_("shipping address"))
    city = models.CharField(_("city"), max_length=50)
    state = models.CharField(_("state"), max_length=50)
    country = CountryField(_("country"),max_length=50)
    zip_code = models.IntegerField(_("zip code"))
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    created_at = models.DateTimeField(_("created at"), auto_now_add=True)

    def __str__(self):
        return str(self.id)

    class Meta:
        verbose_name = "Sipping Address"
        verbose_name_plural = "Shipping Addresses"


class Category(models.Model):
    id = models.BigAutoField(_("id"), primary_key=True, auto_created=True)
    category_name = models.CharField(_("category name"), max_length=50, unique=True)
    created_at = models.DateTimeField(_("created at"), auto_now_add=True)

    def __str__(self):
        return self.category_name

    class Meta:
        verbose_name = "Category"
        verbose_name_plural = "Categories"


class SubCategory(models.Model):
    id = models.BigAutoField(_("id"), primary_key=True, auto_created=True)
    sub_category_name = models.CharField(_("sub category name"), max_length=50, unique=True)
    category = models.ForeignKey(Category, on_delete=models.CASCADE)
    created_at = models.DateTimeField(_("created at"), auto_now_add=True)

    def __str__(self):
        return self.sub_category_name

    class Meta:
        verbose_name = "Sub Category"
        verbose_name_plural = "Sub Categories"


class Product(models.Model):
    id = models.BigAutoField(_("id"), primary_key=True, auto_created=True)
    product_name = models.CharField(_("product name"), max_length=100)
    product_description = models.TextField(_("product description"))
    product_price = models.FloatField(_("product price"))
    product_quantity = models.IntegerField(_("product quantity"))
    product_discount = models.FloatField(_("product discount"), default=0)
    product_image = models.ImageField(_("product image"), upload_to=UploadToPathAndRename("product/images"),
                                      default="", blank=True)
    category = models.ForeignKey(Category, on_delete=models.CASCADE)
    sub_category = models.ForeignKey(SubCategory, on_delete=models.CASCADE)
    created_at = models.DateTimeField(_("created at"), auto_now_add=True)

    def __str__(self):
        return str(self.id)

    class Meta:
        verbose_name = "Product"
        verbose_name_plural = "Products"


class ProductReview(models.Model):
    id = models.BigAutoField(_("id"), primary_key=True, auto_created=True)
    product_rating = models.IntegerField(_("product rating"))
    product_review = models.TextField(_("product review"))
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    created_at = models.DateTimeField(_("created at"), auto_now_add=True)

    def __str__(self):
        return str(self.id)

    class Meta:
        verbose_name = "Product Review"
        verbose_name_plural = "Product Reviews"


class Order(models.Model):
    id = models.BigAutoField(_("id"), primary_key=True, auto_created=True)
    order_delivery_date = models.DateTimeField(_("order delivery date"))
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    is_delivered = models.BooleanField(_("is delivered"), default=False)
    created_at = models.DateTimeField(_("created at"), auto_now_add=True)

    def __str__(self):
        return str(self.id)

    class Meta:
        verbose_name = "Order"
        verbose_name_plural = "Orders"


class OrderDetails(models.Model):
    id = models.BigAutoField(_("id"), primary_key=True, auto_created=True)
    order_quantity = models.IntegerField(_("order quantity"))
    order = models.ForeignKey(Order, on_delete=models.CASCADE)
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    created_at = models.DateTimeField(_("created at"), auto_now_add=True)

    def __str__(self):
        return str(self.id)

    class Meta:
        verbose_name = "Order Details"
        verbose_name_plural = "Orders Details"


class Cart(models.Model):
    id = models.BigAutoField(_("id"), primary_key=True, auto_created=True)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    created_at = models.DateTimeField(_("created at"), auto_now_add=True)

    def __str__(self):
        return str(self.id)

    class Meta:
        verbose_name = "Cart"
        verbose_name_plural = "Cart"


class CartItem(models.Model):
    id = models.BigAutoField(_("id"), primary_key=True, auto_created=True)
    cart_quantity = models.IntegerField(_("cart quantity"))
    cart = models.ForeignKey(Cart, on_delete=models.CASCADE)
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    created_at = models.DateTimeField(_("created at"), auto_now_add=True)

    def __str__(self):
        return str(self.id)

    class Meta:
        verbose_name = "Cart Item"
        verbose_name_plural = "Cart Items"


class ContactUs(models.Model):
    id = models.BigAutoField(_("id"), primary_key=True, auto_created=True)
    first_name = models.CharField(_("first name"), max_length=150)
    last_name = models.CharField(_("last name"), max_length=150)
    email = models.EmailField(_("email"))
    query = models.TextField(_("query"))
    created_at = models.DateTimeField(_("created at"), auto_now_add=True)

    def __str__(self):
        return str(self.id)

    class Meta:
        verbose_name = "Contact us"
        verbose_name_plural = "Contact us"
