from django.urls import path, include

urlpatterns = [
    # path('api/', include(router.urls)),
    path('api/', include("online_shopping.api.urls")),
]
