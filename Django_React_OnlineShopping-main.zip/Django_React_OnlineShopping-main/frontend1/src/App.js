import React from 'react';

import {Route, BrowserRouter, Switch, Link} from 'react-router-dom';
import './index.css';
import Home from './components/Home';
import Product from "./components/Product"
import Login from "./components/Login"
import Header from "./components/Header"
import Footer from "./components/Footer"
import Contactus from './components/Contactus';
import Register from './components/Register';
import Chechout from "./components/Checkout"
function App() {
    return (
        <div className="App">
        
        <BrowserRouter>
        <Header />
            
            <Switch>
            <Route exact path="/" component={Home} />
            <Route path="/products" component={Product} />
            <Route path="/login" component={Login} />
            <Route path="/register" component={Register} />
            
            <Route path="/contactus" component={Contactus} />
            <Route path="/checkout" component={Chechout} />
            <Route component={Error} />
            
            </Switch>
            <Footer />
        </BrowserRouter>
        
        </div>
    );
}


export default App;
