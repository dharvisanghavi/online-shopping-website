import React from "react"
import logo from "../images/logo.jpg"
import { Link, Router, BrowserRouter} from 'react-router-dom';


function Header()
{
    return(
        <div>
        <div class="top-bar">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-sm-6">
                        <i class="fa fa-envelope"></i>
                        support@email.com
                    </div>
                    <div class="col-sm-6">
                        <i class="fa fa-phone-alt"></i>
                        +012-345-6789
                    </div>
                </div>
            </div>
        </div>
        <div class="nav">
            <div class="container-fluid">
                <nav class="navbar navbar-expand-md bg-dark navbar-dark">
                    <Link to="#" class="navbar-brand">MENU</Link>
                    <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
                        <span class="navbar-toggler-icon"></span>
                    </button>

                    <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">
                        <div class="navbar-nav mr-auto">
                            <Link to="/" class="nav-item nav-link">Home</Link>
                            <Link to="/products" class="nav-item nav-link">Products</Link>
                            <Link to="#" class="nav-item nav-link">Product Detail</Link>
                            <Link to="#" class="nav-item nav-link">Cart</Link>
                            <Link to="/checkout" class="nav-item nav-link">Checkout</Link>
                            <Link to="#" class="nav-item nav-link">My Account</Link>
                            <div class="nav-item dropdown">
                                <Link to="#" class="nav-link dropdown-toggle active" data-toggle="dropdown">More Pages</Link>
                                <div class="dropdown-menu">
                                    <Link to="#" class="dropdown-item">Wishlist</Link>
                                    <Link to="/login" class="dropdown-item">Login</Link>
                                    <Link to="/register" class="dropdown-item">Register</Link>
                                    <Link to="/contactus" class="dropdown-item active">Contact Us</Link>
                                </div>
                            </div>
                        </div>
                        <div class="navbar-nav ml-auto">
                            <div class="nav-item dropdown">
                                <Link to="#" class="nav-link dropdown-toggle" data-toggle="dropdown">User Account</Link>
                                <div class="dropdown-menu">
                                    <Link to="#" class="dropdown-item">Login</Link>
                                    <Link to="#" class="dropdown-item">Register</Link>
                                </div>
                            </div>
                        </div>
                    </div>
                </nav>
            </div>
        </div>
       
        <div class="bottom-bar">
            <div class="container-fluid">
                <div class="row align-items-center">
                    <div class="col-md-3">
                        <div class="logo">
                            <Link to="index.html">
                                <img src={logo} alt="Logo" />
                            </Link>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="search">
                            <input type="text" placeholder="Search" />
                            <button><i class="fa fa-search"></i></button>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="user">
                            <Link to="wishlist.html" class="btn wishlist">
                                <i class="fa fa-heart"></i>
                                <span>(0)</span>
                            </Link>
                            <Link to="cart.html" class="btn cart">
                                <i class="fa fa-shopping-cart"></i>
                                <span>(0)</span>
                            </Link>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        </div>
   
    )
}
export default Header
