
import React, { Component } from 'react'
import Navdetail from "./Navdetail"
import { isEmail, isEmpty, isLength, isContainWhiteSpace } from '../shared/validator';
import { Row, FormGroup } from 'react-bootstrap';

import { Link, Router, BrowserRouter} from 'react-router-dom';

class Login extends Component {
    constructor()
    {
        super()
        this.state = {
            formData: {}, // Contains login form data
            errors: {}, // Contains login field errors
            formSubmitted: false, // Indicates submit status of login form
            loading: false
               
      
        }
    }
    validateLoginForm = (e) => {

        let errors = {};
        const { formData } = this.state;

        if (isEmpty(formData.email)) {
            errors.email = "Email can't be blank";
        } else if (!isEmail(formData.email)) {
            errors.email = "Please enter a valid email";
        }

        if (isEmpty(formData.password)) {
            errors.password = "Password can't be blank";
        }  else if (isContainWhiteSpace(formData.password)) {
            errors.password = "Password should not contain white spaces";
        } else if (!isLength(formData.password, { gte: 6, lte: 16, trim: true })) {
            errors.password = "Password's length must between 6 to 16";
        }

        if (isEmpty(errors)) {
            return true;
        } else {
            return errors;
        }
    }
    login = (e) => {

        e.preventDefault();

        let errors = this.validateLoginForm();

        if(errors === true){
            alert("You are successfully signed in...");
            window.location.reload()
        } else {
            this.setState({
                errors: errors,
                formSubmitted: true
            });
        }
    }
    componentDidMount() {
        this.setState({
            login : []
        })
    }
    handleInputChange = (event) => {
        

        const target = event.target;
        const value = target.value;
        const name = target.name;
        
        let { formData } = this.state;
        formData[name] = value;

        this.setState({
            formData: formData
        });
        
    }
    render() {
        const { errors, formSubmitted } = this.state;

        return (
            <div>
            
            <Navdetail data="Login" />
            <form onSubmit={this.login}>
            <div className="login">
            <div className="container-fluid">
                <div className="row align-items-center">
                <div className="col-lg-3"></div>
                    <div className="col-lg-6">
                        <div className="login-form">
                            <div className="row">
                                <div className="col-md-12">
                                    <center><h2>LOGIN</h2><br/></center>
                                   </div>
                                <div className="col-md-6">
                                    <FormGroup controlId="email" validationState={ formSubmitted ? (errors.firstname ? 'error' : 'success') : null }>
                           
                                    <label>E-mail </label>
                                    <input className="form-control" name="email" type="text" onChange={this.handleInputChange} placeholder="E-mail " />  
                                    { errors.email &&
                                        <label style={{color:"red"}}>{errors.email}</label>
                                    }
                                    
                                </FormGroup>
                                </div>
                                <div className="col-md-6">
                                <FormGroup controlId="password" validationState={ formSubmitted ? (errors.password ? 'error' : 'success') : null }>
                           
                                    <label>Password</label>
                                    <input className="form-control" type="password" name="password" placeholder="Password" onChange={this.handleInputChange} />

                                    { errors.password &&
                                        <label style={{color:"red"}}>{errors.password}</label>
                                    }
                                </FormGroup>
                                </div>
                                <div className="col-md-12">
                                    <div className="custom-control custom-checkbox">
                                        <input type="checkbox" className="custom-control-input" id="newaccount" />
                                        <label className="custom-control-label" for="newaccount">Keep me signed in</label>
                                    </div>
                                </div>
                                
                                <div className="col-md-12">
                                    <button className="btn">Submit</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        </form>
        <div className="login m-0" >
            <div className="container-fluid ">
                <div className="row">
                <div className="col-lg-3"></div>
                    <div className="col-lg-6">
                        <div className="login-form">
                            <div className="row">
                                <div className="col-md-12">
                                        <center>
                                         <label>New User? <Link to="">Create an account</Link></label>
                                         </center>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        


            </div>
        )
    }
}

export default Login
    