import React from "react"

function Navdetail(props)
{
    return(
        <div className="breadcrumb-wrap">
            <div className="container-fluid">
                <ul className="breadcrumb">
                    <li className="breadcrumb-item"><a href="#">Home</a></li>
                    <li className="breadcrumb-item"><a href="#">Products</a></li>
                    <li className="breadcrumb-item active">{props.data}</li>
                </ul>
            </div>
        </div>
    )
}
export default Navdetail