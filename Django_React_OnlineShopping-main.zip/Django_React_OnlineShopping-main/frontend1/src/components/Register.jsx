
import React, { Component } from 'react'
import Navdetail from "./Navdetail"
import { isEmail, isMobileno, isLetter, isEmpty, isLength, isContainWhiteSpace } from '../shared/validator';
import { Row, FormGroup } from 'react-bootstrap';



class Register extends Component {
    constructor()
    {
        super()
        this.state = {
            formData: {
                gender:"Gender"
            }, 
            errors: {}, 
            formSubmitted: false, 
            loading: false ,
            file:"",
            imagePreviewUrl:''

      
        }
    }
    validateLoginForm = (e) => {

        let errors = {};
        const { formData } = this.state;
        if (isEmpty(formData.firstname)) {
            errors.firstname = "First name can't be blank";
        } else if (!isLetter(formData.firstname)) {
            errors.firstname = "Please enter a valid name";
        }
        if (isEmpty(formData.lastname)) {
            errors.lastname = "Last name can't be blank";
        } else if (!isLetter(formData.lastname)) {
            errors.lastname = "Please enter a valid Last name";
        }

        if (isEmpty(formData.email)) {
            errors.email = "Email can't be blank";
        } else if (!isEmail(formData.email)) {
            errors.email = "Please enter a valid email";
        }
        if(formData.gender === "Gender")
        {
            errors.gender ="Gender is not selected"
        }
        else{

        }

         if (isEmpty(formData.img)) {
            errors.img = "";
        }
        if (isEmpty(formData.mobileno)) {
            errors.mobileno = "Mobile No can't be blank";
        } else if (!isMobileno(formData.mobileno)) {
            errors.mobileno = "Please enter a Mobile No.";
        }
        
        if (isEmpty(formData.password)) {
            errors.password = "Password can't be blank";
        }  else if (isContainWhiteSpace(formData.password)) {
            errors.password = "Password should not contain white spaces";
        } else if (!isLength(formData.password, { gte: 6, lte: 16, trim: true })) {
            errors.password = "Password's length must between 6 to 16";
        }
        if (isEmpty(formData.rpassword)) {
            errors.rpassword = "Password can't be blank";
        }  else if (formData.rpassword !== formData.password) {
            errors.rpassword = "Password Not match";
        } 

        if (isEmpty(errors)) {
            return true;
        } else {
            return errors;
        }
    }
    register = (e) => {

        e.preventDefault();

        let errors = this.validateLoginForm();

        if(errors === true){
            alert("You are successfully signed in...");
            window.location.reload()
        } else {
            this.setState({
                errors: errors,
                formSubmitted: true
            });
        }
    }
    handleInputChange = (event) => {
       
        const target = event.target;
        const value = target.value;
        const name = target.name;

        let { formData } = this.state;
        formData[name] = value;
       
        this.setState({
            formData: formData
        });
        console.log(this.state.formData)
    }
    
    componentDidMount() {
        this.setState({
            register : []
        })
    }
    render() {
        const { errors, formSubmitted } = this.state;
        console.log(this.state.formData)
        return (
            <div>
            <Navdetail data="Register" />
            <form onSubmit={this.register}>
            <div className="login">
            <div className="container-fluid">
                <div className="row">
                <div className="col-lg-3"> </div>
                    <div className="col-lg-6">    
                        <div className="register-form">
                            <div className="row">
                            <div className="col-md-12">
                                    <center><h2>REGISTER</h2><br/></center>
                                   </div>
                                   
                                <div className="col-md-6">
                                    <FormGroup controlId="firstname" validationState={ formSubmitted ? (errors.firstname ? 'error' : 'success') : null }>
                                    <label>First Name</label>
                                    <input className="form-control" onChange={this.handleInputChange} name="firstname" type="text" placeholder="First Name"/>
                                    { errors.firstname &&
                                        <label style={{color:"red"}}>{errors.firstname}</label>
                                    }
                                   </FormGroup>
                                </div>
                                <div className="col-md-6">
                                    <FormGroup controlId="lastname" validationState={ formSubmitted ? (errors.lastname ? 'error' : 'success') : null }>
                                    <label>Last Name</label>
                                    <input className="form-control" onChange={this.handleInputChange} name="lastname" type="text" placeholder="Last Name"/>
                                    { errors.lastname &&
                                        <label style={{color:"red"}}>{errors.lastname}</label>
                                    }
                                    </FormGroup>
                                </div>
                                
                                <div className="col-md-12">
                                <FormGroup controlId="email" validationState={ formSubmitted ? (errors.firstname ? 'error' : 'success') : null }>
                                <label>E-mail</label>
                                <input className="form-control" name="email" type="text"  onChange={this.handleInputChange} placeholder="E-mail" />  
                                { errors.email && <label style={{color:"red"}}>{errors.email}</label>
                                }
                           
                                </FormGroup>
                                </div>
                                <div class="col-md-6">
                                        <FormGroup controlId="gender" validationState={ formSubmitted ? (errors.gender ? 'error' : 'success') : null }>
                                                      
                                        <label>Gender</label>
                                        <select class="custom-select"  name="gender" onClick={this.handleInputChange}>
                                            <option selected  value="Gender" >Gender</option>
                                            <option value="Male">Male</option>
                                            <option value="Female">Female</option>
                                            
                                        </select>
                                        { errors.gender && <label style={{color:"red"}}>{errors.gender}</label>
                                        }
                                        </FormGroup>
                                </div>
                                
                                <div className="col-md-6">
                                <FormGroup controlId="mobileno" validationState={ formSubmitted ? (errors.mobileno ? 'error' : 'success') : null }>
                                <label>Mobile No</label>
                                <input className="form-control" name="mobileno" type="text" onChange={this.handleInputChange} placeholder="Mobile No" />  
                                { errors.mobileno &&
                                    <label style={{color:"red"}}>{errors.mobileno}</label>
                                }
                           
                                </FormGroup>
                                    
                                </div>
                                <div className="col-md-6">
                                <FormGroup controlId="password" validationState={ formSubmitted ? (errors.password ? 'error' : 'success') : null }>
                                <label>Password</label>
                                <input className="form-control" type="password" name="password" placeholder="Password" onChange={this.handleInputChange} />

                                { errors.password &&
                               <label style={{color:"red"}}>{errors.password}</label>
                                }
                                </FormGroup>
                                </div>
                                <div className="col-md-6">
                                <FormGroup controlId="rpassword" validationState={ formSubmitted ? (errors.rpassword ? 'error' : 'success') : null }>
                                <label>Password</label>
                                <input className="form-control" type="password" name="rpassword" placeholder="Password" onChange={this.handleInputChange} />

                                { errors.rpassword &&
                               <label style={{color:"red"}}>{errors.rpassword}</label>
                                }
                                </FormGroup>
                                </div>
                                <div className="col-md-6">
                                    <FormGroup controlId="img" validationState={ formSubmitted ? (errors.img ? 'error' : 'success') : null }>
                                    <label>Upload Your Image</label>
                                    <input style={{color:"red"}} onChange={this.handleInputChange} type="file" id="img"  name="img" accept="image/*"/>
                                    { errors.img &&
                                    <label style={{color:"red"}}>{errors.img}</label>
                                    }
                                    </FormGroup>
                                </div>
                                <div className="col-md-12"> <br/></div>
                                
                                <div className="col-md-12">
                                    <button className="btn">Submit</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
        </form>

            </div>
        )
    }
}

export default Register
    