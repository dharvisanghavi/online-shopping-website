
import React, { Component } from 'react'
import Productitems from "./Productitems"
import productdata from "./productdata"
import axios from 'axios'
const ai = axios.create({
      baseURL: 'http://127.0.0.1:8000/api/'
    })
class Products extends Component {
    constructor()
    {
        super()
        this.state = {
            Products : []
               
      
        }
    }
    componentDidMount() {
        ai.get('/products/')
        .then((res) => {
          console.log(res.data)
          this.setState({ Products: res.data })
          console.log(this.state.items)
        })
       
    }
    render() {
        const productItems = this.state.Products.map(productitems => <Productitems key={productitems} item={productitems} />)
       
        return (
            <div>
                
                <div class="row">
                {this.state.Products.map(productitems => <Productitems key={productitems} item={productitems} />)}
                </div>
            
            </div>
        )
    }
}

export default Products
    