const productdata = [
    {
        id: 1,
        product_name: "product 1",
        product_price:"2",
        product_image : "/images/productimage.jpg"
    },
    {
        id: 2,
        product_name: "product 5",
        product_price:"9",
        product_image : "/images/productimage.jpg"
    },
    {
        id: 3,
        product_name: "product 3",
        product_price:"6",
        product_image : "/images/productimage.jpg"
    },
    {
        id: 4,
        product_name: "product 6",
        product_price:"300",
        product_image : "/images/productimage.jpg"
    },
    {
        id: 5,
        product_name: "product 5",
        product_price:"5",
        product_image : "/images/productimage.jpg"
    },
    {
        id: 6,
        product_name: "product 6",
        product_price:"300",
        product_image : "/images/productimage.jpg"
    },
    {
        id: 7,
        product_name: "product 5",
        product_price:"5",
        product_image : "/images/productimage.jpg"
    },
    {
        id: 8,
        product_name: "product 6",
        product_price:"300",
        product_image : "/images/productimage.jpg"
    },
    {
        id: 9,
        product_name: "product 5",
        product_price:"5",
        product_image : "/images/productimage.jpg"
    },{
        id: 10,
        product_name: "product 5",
        product_price:"5",
        product_image : "/images/productimage.jpg"
    }
]

export default productdata